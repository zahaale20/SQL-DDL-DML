Alex Zaharia
azaharia@calpoly.edu
LAB 2, PART 2

- My first concern is that I wasn't able to figure out how to test my files using the given ones (build-all.sql, test-all.sql, clean-all.sql, full-run.sql). Instead I manually tested all the statements in correct order and my queries ran fine.

- My second concern is with the Keys (Primary, Foreign, Unique). I understand what they mean and how they are supposed to be applied, however, I ran into issues with some of them and decided to remove them so that my program was at least running smoothly.

- My final concern is possibly the structure of the files. I went through and believe it's all correct, but I am still worried in the back of my mind that I miss typed something or made an error somewhere along the way.

- I feel like this lab was extremely time consuming, however, I do feel like I learned a lot and have made significant progress towards my understanding SQL since the start of class.
