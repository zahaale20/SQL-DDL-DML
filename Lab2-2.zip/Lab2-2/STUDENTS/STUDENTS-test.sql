-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM list;
SELECT * FROM teachers;
SELECT COUNT(*) FROM list;
SELECT COUNT(*) FROM teachers;