-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS list;
DROP TABLE IF EXISTS teachers;
