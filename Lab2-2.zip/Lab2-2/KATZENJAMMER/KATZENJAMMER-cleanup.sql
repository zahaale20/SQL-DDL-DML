-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS Tracklists;
DROP TABLE IF EXISTS Performance;
DROP TABLE IF EXISTS Instruments;
DROP TABLE IF EXISTS Vocals;
DROP TABLE IF EXISTS Band;
DROP TABLE IF EXISTS Songs;
DROP TABLE IF EXISTS Albums;