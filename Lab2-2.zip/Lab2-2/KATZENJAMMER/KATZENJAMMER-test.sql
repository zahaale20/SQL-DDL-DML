-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM Albums;
SELECT * FROM Songs;
SELECT * FROM Band;
SELECT * FROM Vocals;
SELECT * FROM Instruments;
SELECT * FROM Performance;
SELECT * FROM Tracklists;
SELECT COUNT(*) FROM Albums;
SELECT COUNT(*) FROM Songs;
SELECT COUNT(*) FROM Band;
SELECT COUNT(*) FROM Vocals;
SELECT COUNT(*) FROM Instruments;
SELECT COUNT(*) FROM Performance;
SELECT COUNT(*) FROM Tracklists;