-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS Faculty;
DROP TABLE IF EXISTS Enrollments;
DROP TABLE IF EXISTS DisciplineEnrollments;
DROP TABLE IF EXISTS Disciplines;
DROP TABLE IF EXISTS Degree;
DROP TABLE IF EXISTS CSUFees;
DROP TABLE IF EXISTS Campuses;