-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM Campuses;
SELECT * FROM CSUFees;
SELECT * FROM Degrees;
SELECT * FROM Disciplines;
SELECT * FROM DisciplineEnrollments;
SELECT * FROM Enrollments;
SELECT * FROM Faculty;
SELECT COUNT(*) FROM Campuses;
SELECT COUNT(*) FROM CSUFees;
SELECT COUNT(*) FROM Degrees;
SELECT COUNT(*) FROM Disciplines;
SELECT COUNT(*) FROM DisciplineEnrollments;
SELECT COUNT(*) FROM Enrollments;
SELECT COUNT(*) FROM Faculty;
