-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

INSERT INTO grapes VALUES (1, 'Barbera', 'Red');
INSERT INTO grapes VALUES (2, 'Cabernet Franc', 'Red');
INSERT INTO grapes VALUES (3, 'Cabernet Sauvingnon', 'Red');
INSERT INTO grapes VALUES (4, 'Chardonnay', 'White');
INSERT INTO grapes VALUES (5, 'Grenache', 'Red');
INSERT INTO grapes VALUES (6, 'Malbec', 'Red');
INSERT INTO grapes VALUES (7, 'Marsanne', 'White');
INSERT INTO grapes VALUES (8, 'Merlot', 'Red');
INSERT INTO grapes VALUES (9, 'Mourvedre', 'Red');
INSERT INTO grapes VALUES (10, 'Muscat', 'White');
INSERT INTO grapes VALUES (11, 'Petite Sirah', 'Red');
INSERT INTO grapes VALUES (12, 'Pinot Noir', 'Red');
INSERT INTO grapes VALUES (13, 'Riesling', 'White');
INSERT INTO grapes VALUES (14, 'Roussanne', 'White');
INSERT INTO grapes VALUES (15, 'Sangiovese', 'Red');
INSERT INTO grapes VALUES (16, 'Sauvignon Blanc', 'White');
INSERT INTO grapes VALUES (17, 'Syrah', 'Red');
INSERT INTO grapes VALUES (18, 'Tempranillo', 'Red');
INSERT INTO grapes VALUES (19, 'Viognier', 'White');
INSERT INTO grapes VALUES (20, 'Zinfandel', 'Red');