-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM appellations;
SELECT * FROM grapes;
SELECT * FROM wine;
SELECT COUNT(*) FROM appellations;
SELECT COUNT(*) FROM grapes;
SELECT COUNT(*) FROM wine;