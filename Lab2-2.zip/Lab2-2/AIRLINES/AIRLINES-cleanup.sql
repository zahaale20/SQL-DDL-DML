-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS airports100;
DROP TABLE IF EXISTS airlines;