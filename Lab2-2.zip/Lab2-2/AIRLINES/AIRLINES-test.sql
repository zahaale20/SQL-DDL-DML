-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM airlines;
SELECT * FROM airports100;
SELECT * FROM flights;
SELECT COUNT(*) FROM airlines;
SELECT COUNT(*) FROM airports100;
SELECT COUNT(*) FROM flights;