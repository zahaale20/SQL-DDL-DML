-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

INSERT INTO Rooms VALUES ('RND', 'Recluse and defiance', 1, 'King', 2, 150, 'modern');
INSERT INTO Rooms VALUES ('IBS', 'Interim but salutary', 1, 'King', 2, 150, 'traditional');
INSERT INTO Rooms VALUES ('AOB', 'Abscond or bolster', 2, 'Queen', 4, 175, 'traditional');
INSERT INTO Rooms VALUES ('MWC', 'Mendicant with cryptic', 2, 'Double', 4, 125, 'modern');
INSERT INTO Rooms VALUES ('HBB', 'Harbinger but bequest', 1, 'Queen', 2, 100, 'modern');
INSERT INTO Rooms VALUES ('IBD', 'Immutable before decorum', 2, 'Queen', 4, 150, 'rustic');
INSERT INTO Rooms VALUES ('TAA', 'Thrift and accolade', 1, 'Double', 2, 75, 'modern');
INSERT INTO Rooms VALUES ('CAS', 'Convoke and sanguine', 2, 'King', 4, 175, 'traditional');
INSERT INTO Rooms VALUES ('RTE', 'Riddle to exculpate', 2, 'Queen', 4, 175, 'rustic');
INSERT INTO Rooms VALUES ('FNA', 'Frugal not apropos', 2, 'King', 4, 250, 'traditional');