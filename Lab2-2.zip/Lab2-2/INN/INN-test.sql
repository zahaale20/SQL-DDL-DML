-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM Rooms;
SELECT * FROM Reservations;
SELECT COUNT(*) FROM Rooms;
SELECT COUNT(*) FROM Reservations;