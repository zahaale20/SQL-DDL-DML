-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM Continents;
SELECT * FROM Countries;
SELECT * FROM CarMakers;
SELECT * FROM CarNames;
SELECT * FROM CarsData;
SELECT * FROM ModelList;
SELECT COUNT(*) FROM Continents;
SELECT COUNT(*) FROM Countries;
SELECT COUNT(*) FROM CarMakers;
SELECT COUNT(*) FROM CarNames;
SELECT COUNT(*) FROM CarsData;
SELECT COUNT(*) FROM ModelList;