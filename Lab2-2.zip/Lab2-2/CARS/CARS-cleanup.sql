-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS ModelList;
DROP TABLE IF EXISTS CarsData;
DROP TABLE IF EXISTS CarNames;
DROP TABLE IF EXISTS CarMakers;
DROP TABLE IF EXISTS Countries;
DROP TABLE IF EXISTS Continents;