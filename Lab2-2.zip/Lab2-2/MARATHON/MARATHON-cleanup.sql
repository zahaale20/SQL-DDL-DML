-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

DROP TABLE IF EXISTS marathon;