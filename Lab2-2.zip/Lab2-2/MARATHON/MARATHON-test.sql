-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023

SELECT * FROM marathon;
SELECT COUNT(*) FROM marathon;