-- Alex Zaharia
-- azaharia@calpoly.edu
-- Apr 19, 2023


SELECT * FROM customers;
SELECT * FROM goods;
SELECT * FROM receipts;
SELECT * FROM items;
SELECT COUNT(*) FROM customers;
SELECT COUNT(*) FROM goods;
SELECT COUNT(*) FROM receipts;
SELECT COUNT(*) FROM items;